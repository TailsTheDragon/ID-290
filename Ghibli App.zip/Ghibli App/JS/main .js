$(document).append('<div data-selection="cat" class="btn" id="btn1">option1</div><div data-selection="dog" class="btn" id="btn2">option2</div><div data-selection="bird" class="btn" id="btn3">option3</div><div data-selection="lizard" class="btn" id="btn4">option4</div>')

var selection;

$('btn').click(function(){
	selection = $(this).attr("data-selection");
	console.log(selection);
})
