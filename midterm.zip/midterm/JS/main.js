$('#submit').click(function(result){
	alert('finding your pokemon...');

	var s = $('#pokeInput').val();
	var url = 'https://pokeapi.co/api/v2/pokemon/' + s + '/';
	
	$.getJSON(url)
	.done(function(result){
		$('#nameBox').html('<h1>' + result.name + '</h1')
		function sayStats(){
			responsiveVoice.speak("This Pokemon is " + result.name + 'and is' + result.weight + 'pounds', "UK English Male", {pitch: 1});
		}
		responsiveVoice.speak("Welcome, Trainer!", "UK English Male", {pitch: 1, onend: sayStats});
		console.log(result);
	}).fail(function(){
		responsiveVoice.speak("No Pokemon found", {pitch: 1});
	});
});

$('#berries').click(function(result){
	alert('finding your berry...');
	var s = $('#berryInput').val();
	var url = 'https://pokeapi.co/api/v2/berry/' + s + '/';
	
	$.getJSON(url)
	.done(function(result){
		$('#nameBox').html('<h1>' + result.name + '</h1>');
		$('#spriteBox').html('<img src="../Images/Sprites/Berries/' + result.name + '.png"/>');
		function sayStats(){
			responsiveVoice.speak("This berry is a" + result.name + 'berry', "UK English Male", {pitch: 1});
		}
		responsiveVoice.speak("Welcome, Trainer!", "UK English Male", {pitch: 1, onend: sayStats});
		console.log(result);
	}).fail(function(){
		responsiveVoice.speak("No Pokemon found", {pitch: 1});
	});
});



