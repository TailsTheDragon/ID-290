var qArray = ["How to define a variable","List an example of an Event Listener","Q3", "Q4"]
var aArray = ["var","click","A3","A4"]
var questionCount = 0;
var answerCount = 0;

var questionBox = document.getElementById('questionBox')
var answerBox = document.getElementById('answerBox')
var input = document.getElementById('input')
var checkBtn = document.getElementById('checkBtn')
var modalBox = document.getElementById('modalBox')
var answerText = document.getElementById('answerText')
var question = document.getElementById('question')

modalBox.addEventListener("click", hideModal);
checkBtn.addEventListener("click", checkAnswer);

function hideModal(){
	modalBox.style.opacity = "0";
	modalBox.style.marginTop = "-100vh";
	showQuestionBox();
	nextCard();
}

function showModal (){
	modalBox.style.opacity = "1";
	modalBox.style.marginTop = "0vh";
	hideQuestionBox();
}

function hideQuestionBox (){
	questionBox.style.opacity = "0";
	questionBox.style.marginTop = "-500px";

}

function showQuestionBox(){
questionBox.style.opacity = "1";
questionBox.style.marginTop = "200px";
}

function checkAnswer(){
	showModal();
	//Code to show answer
	answerBox.innerHTML = aArray[answerCount];
	answerCount++;
	showModal();
}

function nextCard(){
	question.innerHTML = qArray[questionCount];
	questionCount++;
	showQuestionBox();
}