$('#weather').click(function(){
	$.getJSON('http://api.openweathermap.org/data/2.5/weather?zip=' + $('#zipInput').val() + '&AAPID=ffbaed99f10375462add667213061774');
		console.log('result');
});